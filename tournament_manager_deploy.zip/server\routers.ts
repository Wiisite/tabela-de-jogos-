import { TRPCError } from "@trpc/server";
import { z } from "zod";
import {
  createMatch,
  createTeam,
  createTournament,
  getAllTournaments,
  getMatchesByPhase,
  getMatchesByTournament,
  getMatchById,
  getTeamsByTournament,
  getTournamentById,
  updateMatchScore,
  updateMatchDetails,
  updateTournamentStatus,
  updateTournament,
  deleteTournament,
  resetMatchScore,
  getAllPortals,
  getPortalBySlug,
  createPortal,
  updatePortal,
  deletePortal,
  updateTeam,
  deleteTeam,
  deleteMatchesByTournament,
} from "./db";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";

// ─── Round-robin schedule helper (circle method) ──────────────────────────────

/**
 * Generates round-robin pairs using the circle method.
 * Each round contains non-overlapping games (teams don't play twice per round).
 * Returns array of { home, away, round } for the turno.
 */
function generateCircleSchedule(teamIds: number[]): { home: number; away: number; round: number }[] {
  const list = [...teamIds];
  const isOdd = list.length % 2 !== 0;
  if (isOdd) list.push(-1); // dummy for bye rounds

  const n = list.length;
  const numRounds = n - 1;
  const halfSize = n / 2;
  const result: { home: number; away: number; round: number }[] = [];

  const fixed = list[0];
  const rotating = list.slice(1);

  for (let round = 0; round < numRounds; round++) {
    const current = [fixed, ...rotating];
    for (let i = 0; i < halfSize; i++) {
      const home = current[i];
      const away = current[n - 1 - i];
      if (home !== -1 && away !== -1) {
        result.push({ home, away, round: round + 1 });
      }
    }
    // Rotate: keep first element fixed, rotate the rest
    const last = rotating.pop()!;
    rotating.unshift(last);
  }

  return result;
}

// ─── Standings helper ──────────────────────────────────────────────────────────

type StandingEntry = {
  teamId: number;
  teamName: string;
  shortName: string;
  color: string;
  logo: string | null;
  groupName: string;
  played: number;
  won: number;
  drawn: number;
  lost: number;
  goalsFor: number;
  goalsAgainst: number;
  goalDiff: number;
  points: number;
};

function computeStandings(
  teamList: { id: number; name: string; shortName: string; color: string; groupName: string; logo?: string | null }[],
  groupMatches: {
    homeTeamId: number;
    awayTeamId: number;
    homeScore: number | null;
    awayScore: number | null;
    status: string;
  }[],
  pointsConfig: { win: number; draw: number; loss: number } = { win: 3, draw: 1, loss: 0 }
): StandingEntry[] {
  const map = new Map<number, StandingEntry>();
  for (const t of teamList) {
    map.set(t.id, {
      teamId: t.id,
      teamName: t.name,
      shortName: t.shortName,
      color: t.color,
      logo: t.logo ?? null,
      groupName: t.groupName,
      played: 0,
      won: 0,
      drawn: 0,
      lost: 0,
      goalsFor: 0,
      goalsAgainst: 0,
      goalDiff: 0,
      points: 0,
    });
  }

  for (const m of groupMatches) {
    if (m.status !== "finished" || m.homeScore === null || m.awayScore === null) continue;
    const home = map.get(m.homeTeamId);
    const away = map.get(m.awayTeamId);
    if (!home || !away) continue;

    home.played++;
    away.played++;
    home.goalsFor += m.homeScore;
    home.goalsAgainst += m.awayScore;
    away.goalsFor += m.awayScore;
    away.goalsAgainst += m.homeScore;

    if (m.homeScore > m.awayScore) {
      home.won++;
      home.points += pointsConfig.win;
      away.lost++;
      away.points += pointsConfig.loss;
    } else if (m.homeScore < m.awayScore) {
      away.won++;
      away.points += pointsConfig.win;
      home.lost++;
      home.points += pointsConfig.loss;
    } else {
      home.drawn++;
      away.drawn++;
      home.points += pointsConfig.draw;
      away.points += pointsConfig.draw;
    }
  }

  const entries = Array.from(map.values());
  for (const entry of entries) {
    entry.goalDiff = entry.goalsFor - entry.goalsAgainst;
  }

  // Sorting with Tie-breakers: Points > Victories > Goal Diff > Goals For > Head-to-Head
  return entries.sort((a, b) => {
    if (b.points !== a.points) return b.points - a.points;
    if (b.won !== a.won) return b.won - a.won;
    if (b.goalDiff !== a.goalDiff) return b.goalDiff - a.goalDiff;
    if (b.goalsFor !== a.goalsFor) return b.goalsFor - a.goalsFor;

    // Head-to-head (very simplified for this version: find match between them)
    const h2hMatch = groupMatches.find(
      (m) =>
        m.status === "finished" &&
        ((m.homeTeamId === a.teamId && m.awayTeamId === b.teamId) ||
          (m.homeTeamId === b.teamId && m.awayTeamId === a.teamId))
    );
    if (h2hMatch && h2hMatch.homeScore !== h2hMatch.awayScore) {
      const aScore = h2hMatch.homeTeamId === a.teamId ? h2hMatch.homeScore! : h2hMatch.awayScore!;
      const bScore = h2hMatch.homeTeamId === b.teamId ? h2hMatch.homeScore! : h2hMatch.awayScore!;
      return bScore - aScore;
    }

    return 0;
  });
}

// ─── Seed helper ───────────────────────────────────────────────────────────────

const DEFAULT_TEAMS = [
  { name: "Colégio Beryon", shortName: "BRY", color: "#1e3a8a" },
  { name: "Colégio Educar", shortName: "EDU", color: "#166534" },
  { name: "Colégio Santa Rita", shortName: "CSR", color: "#7c3aed" },
  { name: "Colégio Marconi", shortName: "MCN", color: "#b91c1c" },
  { name: "Colégio Parthenon", shortName: "PTH", color: "#d97706" },
  { name: "Colégio Canada", shortName: "CDA", color: "#0e7490" },
];

// ─── Portal Router ─────────────────────────────────────────────────────────────

const portalRouter = router({
  list: publicProcedure.query(async () => {
    return getAllPortals();
  }),
  getBySlug: publicProcedure.input(z.object({ slug: z.string() })).query(async ({ input }) => {
    const portal = await getPortalBySlug(input.slug);
    if (!portal) throw new TRPCError({ code: "NOT_FOUND", message: "Portal não encontrado" });
    return portal;
  }),
  create: protectedProcedure
    .input(
      z.object({
        name: z.string().min(1),
        slug: z.string().min(1),
        logo: z.string().nullable().optional(),
        primaryColor: z.string().optional(),
        secondaryColor: z.string().optional(),
        adminPassword: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const existing = await getPortalBySlug(input.slug);
      if (existing) throw new TRPCError({ code: "BAD_REQUEST", message: "Este slug já está em uso" });
      const id = await createPortal(input);
      return { id };
    }),
  delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
    await deletePortal(input.id);
    return { ok: true };
  }),
  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        name: z.string().optional(),
        logo: z.string().nullable().optional(),
        banner: z.string().nullable().optional(),
        primaryColor: z.string().optional(),
        secondaryColor: z.string().optional(),
        fontFamily: z.string().optional(),
        adminPassword: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      await updatePortal(input.id, input);
      return { ok: true };
    }),
});

// ─── Tournament Router ─────────────────────────────────────────────────────────

const tournamentRouter = router({
  list: publicProcedure.input(z.object({ portalId: z.number().optional() }).optional()).query(async ({ input }) => {
    return getAllTournaments(input?.portalId);
  }),

  getGlobalStats: publicProcedure.query(async () => {
    const stats = await import("./db").then((db) => db.getGlobalStats());
    return stats;
  }),

  getById: publicProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
    const tournament = await getTournamentById(input.id);
    if (!tournament) throw new TRPCError({ code: "NOT_FOUND", message: "Torneio não encontrado" });
    const teamList = await getTeamsByTournament(input.id);
    const matchList = await getMatchesByTournament(input.id);
    return { tournament, teams: teamList, matches: matchList };
  }),

  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const tournament = await getTournamentById(input.id);
      if (!tournament) throw new TRPCError({ code: "NOT_FOUND", message: "Torneio não encontrado" });
      await deleteTournament(input.id);
      return { ok: true };
    }),

  create: protectedProcedure
    .input(
      z.object({
        portalId: z.number().default(1),
        name: z.string().min(1),
        category: z.string().min(1),
        sport: z.enum(["football", "basketball", "volleyball", "handball", "futsal"]).default("football"),
        groupCount: z.number().min(1).max(4).default(1),
        winPoints: z.number().default(3),
        drawPoints: z.number().default(1),
        lossPoints: z.number().default(0),
        isDoubleRound: z.boolean().default(false),
        teams: z
          .array(
            z.object({
              name: z.string().min(1),
              shortName: z.string().min(1).max(10),
              color: z.string().default("#1e40af"),
              groupName: z.string().default("A"),
              logo: z.string().nullable().optional(),
            })
          )
          .min(2),
        slider: z.string().nullable().optional(),
        sponsors: z.string().nullable().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      // If portal admin, override portalId with their assigned portal
      const portalId = (ctx.user?.role === 'admin' && ctx.user.portalId) ? ctx.user.portalId : input.portalId;

      const tournamentId = await createTournament(portalId, input.name, input.category, {
        sport: input.sport,
        groupCount: input.groupCount,
        winPoints: input.winPoints,
        drawPoints: input.drawPoints,
        lossPoints: input.lossPoints,
        isDoubleRound: input.isDoubleRound,
        slider: input.slider,
        sponsors: input.sponsors,
      });

      // Insert teams with their assigned groups
      for (const t of input.teams) {
        await createTeam(tournamentId, t.name, t.shortName, t.color, t.groupName, t.logo);
      }
      return { id: tournamentId };
    }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        name: z.string().optional(),
        category: z.string().optional(),
        sport: z.enum(["football", "basketball", "volleyball", "handball", "futsal"]).optional(),
        groupCount: z.number().min(1).max(4).optional(),
        winPoints: z.number().optional(),
        drawPoints: z.number().optional(),
        lossPoints: z.number().optional(),
        isDoubleRound: z.boolean().optional(),
        champion: z.string().nullable().optional(),
        slider: z.string().nullable().optional(),
        sponsors: z.string().nullable().optional(),
        teams: z
          .array(
            z.object({
              id: z.number().optional(), // If provided, update; else create
              name: z.string().min(1),
              shortName: z.string().min(1).max(10),
              color: z.string(),
              groupName: z.string().default("A"),
              logo: z.string().nullable().optional(),
            })
          )
          .optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, teams: inputTeams, ...updateData } = input;
      
      // Update basic info
      await updateTournament(id, updateData);

      // Systematically reconcile teams if provided
      if (inputTeams) {
        const existingTeams = await getTeamsByTournament(id);
        const existingIds = existingTeams.map(t => t.id);
        const inputIds = inputTeams.map(t => t.id).filter((tid): tid is number => !!tid);

        // Delete removed teams
        for (const et of existingTeams) {
          if (!inputIds.includes(et.id)) {
            await deleteTeam(et.id);
          }
        }

        // Update or Create
        for (const it of inputTeams) {
          if (it.id && existingIds.includes(it.id)) {
            await updateTeam(it.id, {
              name: it.name,
              shortName: it.shortName,
              color: it.color,
              groupName: it.groupName,
              logo: it.logo
            });
          } else {
            await createTeam(id, it.name, it.shortName, it.color, it.groupName, it.logo);
          }
        }
      }

      return { ok: true };
    }),

  generateGroupMatches: protectedProcedure
    .input(z.object({ tournamentId: z.number(), clearExisting: z.boolean().default(false) }))
    .mutation(async ({ input }) => {
      const tournament = await getTournamentById(input.tournamentId);
      if (!tournament) throw new TRPCError({ code: "NOT_FOUND" });

      if (input.clearExisting) {
        await deleteMatchesByTournament(input.tournamentId, "group");
      } else {
        const existing = await getMatchesByPhase(input.tournamentId, "group");
        if (existing.length > 0) throw new TRPCError({ code: "BAD_REQUEST", message: "Confrontos já gerados" });
      }

      const teamList = await getTeamsByTournament(input.tournamentId);

      // Group teams by groupName
      const groups: Record<string, typeof teamList> = {};
      for (const t of teamList) {
        if (!groups[t.groupName]) groups[t.groupName] = [];
        groups[t.groupName].push(t);
      }

      for (const groupName in groups) {
        const groupTeams = groups[groupName];
        if (groupTeams.length < 2) continue;

        const turno = generateCircleSchedule(groupTeams.map((t) => t.id));

        // Turno
        for (const { home, away, round } of turno) {
          await createMatch(input.tournamentId, "group", home, away, round);
        }

        // Returno (reverse fixtures, rounds continue after turno)
        if (tournament.isDoubleRound) {
          const numTurnoRounds = turno.length > 0 ? Math.max(...turno.map((g) => g.round)) : 0;
          for (const { home, away, round } of turno) {
            await createMatch(input.tournamentId, "group", away, home, numTurnoRounds + round);
          }
        }
      }

      await updateTournamentStatus(input.tournamentId, "group_stage");
      return { ok: true };
    }),

  getStandings: publicProcedure
    .input(z.object({ tournamentId: z.number() }))
    .query(async ({ input }) => {
      const tournament = await getTournamentById(input.tournamentId);
      if (!tournament) throw new TRPCError({ code: "NOT_FOUND" });
      const teamList = await getTeamsByTournament(input.tournamentId);
      const groupMatches = await getMatchesByPhase(input.tournamentId, "group");
      
      const pointsConfig = {
        win: tournament.winPoints,
        draw: tournament.drawPoints,
        loss: tournament.lossPoints,
      };

      // Calculate standings per group
      const groups = Array.from(new Set(teamList.map((t) => t.groupName))).sort();
      const standingsByGroup: Record<string, StandingEntry[]> = {};

      for (const g of groups) {
        const gTeams = teamList.filter((t) => t.groupName === g);
        const gMatches = groupMatches.filter((m) => {
          const home = gTeams.find(t => t.id === m.homeTeamId);
          const away = gTeams.find(t => t.id === m.awayTeamId);
          return !!home && !!away;
        });
        standingsByGroup[g] = computeStandings(gTeams, gMatches, pointsConfig);
      }

      return standingsByGroup;
    }),

  generateSemifinals: protectedProcedure
    .input(z.object({ tournamentId: z.number() }))
    .mutation(async ({ input }) => {
      const tournament = await getTournamentById(input.tournamentId);
      if (!tournament) throw new TRPCError({ code: "NOT_FOUND" });
      
      const teamList = await getTeamsByTournament(input.tournamentId);
      const groupMatches = await getMatchesByPhase(input.tournamentId, "group");
      const unfinished = groupMatches.filter((m) => m.status !== "finished");
      if (unfinished.length > 0)
        throw new TRPCError({ code: "BAD_REQUEST", message: "Ainda há partidas da fase de grupos em aberto" });

      const existing = await getMatchesByPhase(input.tournamentId, "semifinal");
      if (existing.length > 0) throw new TRPCError({ code: "BAD_REQUEST", message: "Semifinais já geradas" });

      const pointsConfig = { win: tournament.winPoints, draw: tournament.drawPoints, loss: tournament.lossPoints };

      if (tournament.groupCount === 1) {
        const standings = computeStandings(teamList, groupMatches, pointsConfig);
        if (standings.length < 4) throw new TRPCError({ code: "BAD_REQUEST", message: "Mínimo 4 equipes para semis" });
        // 1º vs 4º, 2º vs 3º
        await createMatch(input.tournamentId, "semifinal", standings[0].teamId, standings[3].teamId, 1);
        await createMatch(input.tournamentId, "semifinal", standings[1].teamId, standings[2].teamId, 2);
      } else if (tournament.groupCount === 2) {
        const sA = computeStandings(teamList.filter(t => t.groupName === "A"), groupMatches, pointsConfig);
        const sB = computeStandings(teamList.filter(t => t.groupName === "B"), groupMatches, pointsConfig);
        if (sA.length < 2 || sB.length < 2) throw new TRPCError({ code: "BAD_REQUEST", message: "Mínimo 2 equipes por grupo" });
        // A1 vs B2, B1 vs A2
        await createMatch(input.tournamentId, "semifinal", sA[0].teamId, sB[1].teamId, 1);
        await createMatch(input.tournamentId, "semifinal", sB[0].teamId, sA[1].teamId, 2);
      } else if (tournament.groupCount === 3) {
        // 3 grupos: A1, B1, C1 + melhor 2º colocado de todos os grupos
        const sA = computeStandings(teamList.filter(t => t.groupName === "A"), groupMatches, pointsConfig);
        const sB = computeStandings(teamList.filter(t => t.groupName === "B"), groupMatches, pointsConfig);
        const sC = computeStandings(teamList.filter(t => t.groupName === "C"), groupMatches, pointsConfig);
        if (!sA[0] || !sB[0] || !sC[0]) throw new TRPCError({ code: "BAD_REQUEST", message: "Mínimo 1 equipe por grupo" });
        // Melhor 2º colocado (por pontos, vitórias, saldo de gols, gols pró)
        const runners = [sA[1], sB[1], sC[1]].filter(Boolean).sort((a, b) => {
          if (b.points !== a.points) return b.points - a.points;
          if (b.won !== a.won) return b.won - a.won;
          if (b.goalDiff !== a.goalDiff) return b.goalDiff - a.goalDiff;
          return b.goalsFor - a.goalsFor;
        });
        if (!runners[0]) throw new TRPCError({ code: "BAD_REQUEST", message: "Mínimo 2 equipes por grupo para gerar semis" });
        const bestRunner = runners[0];
        // Semifinais: A1 vs bestRunner, B1 vs C1
        await createMatch(input.tournamentId, "semifinal", sA[0].teamId, bestRunner.teamId, 1);
        await createMatch(input.tournamentId, "semifinal", sB[0].teamId, sC[0].teamId, 2);
      } else if (tournament.groupCount === 4) {
        const sA = computeStandings(teamList.filter(t => t.groupName === "A"), groupMatches, pointsConfig);
        const sB = computeStandings(teamList.filter(t => t.groupName === "B"), groupMatches, pointsConfig);
        const sC = computeStandings(teamList.filter(t => t.groupName === "C"), groupMatches, pointsConfig);
        const sD = computeStandings(teamList.filter(t => t.groupName === "D"), groupMatches, pointsConfig);
        // A1 vs D1, B1 vs C1
        await createMatch(input.tournamentId, "semifinal", sA[0].teamId, sD[0].teamId, 1);
        await createMatch(input.tournamentId, "semifinal", sB[0].teamId, sC[0].teamId, 2);
      } else {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Formato de grupos não suportado" });
      }

      await updateTournamentStatus(input.tournamentId, "semifinals");
      return { ok: true };
    }),

  generateFinal: protectedProcedure
    .input(z.object({ tournamentId: z.number() }))
    .mutation(async ({ input }) => {
      const semis = await getMatchesByPhase(input.tournamentId, "semifinal");
      const unfinished = semis.filter((m) => m.status !== "finished");
      if (unfinished.length > 0)
        throw new TRPCError({ code: "BAD_REQUEST", message: "Ainda há semifinais em aberto" });

      const existing = await getMatchesByPhase(input.tournamentId, "final");
      if (existing.length > 0) throw new TRPCError({ code: "BAD_REQUEST", message: "Final já gerada" });

      const getWinnerAndLoser = (m: typeof semis[0]) => {
        const hS = m.homeScore! + (m.homePenalties ?? 0);
        const aS = m.awayScore! + (m.awayPenalties ?? 0);
        if (hS > aS) return { winner: m.homeTeamId, loser: m.awayTeamId };
        return { winner: m.awayTeamId, loser: m.homeTeamId };
      };

      const semi1 = semis.find((m) => m.round === 1)!;
      const semi2 = semis.find((m) => m.round === 2)!;
      const res1 = getWinnerAndLoser(semi1);
      const res2 = getWinnerAndLoser(semi2);

      // Final
      await createMatch(input.tournamentId, "final", res1.winner, res2.winner, 1);
      // Third place
      await createMatch(input.tournamentId, "third_place", res1.loser, res2.loser, 1);

      await updateTournamentStatus(input.tournamentId, "final");
      return { ok: true };
    }),

  getBracket: publicProcedure
    .input(z.object({ tournamentId: z.number() }))
    .query(async ({ input }) => {
      const teamList = await getTeamsByTournament(input.tournamentId);
      const allMatches = await getMatchesByTournament(input.tournamentId);
      const teamMap = new Map(teamList.map((t) => [t.id, t]));
      const enrich = (m: (typeof allMatches)[0]) => ({
        ...m,
        homeTeam: teamMap.get(m.homeTeamId),
        awayTeam: teamMap.get(m.awayTeamId),
      });
      return {
        group: allMatches.filter((m) => m.phase === "group").map(enrich),
        semifinal: allMatches.filter((m) => m.phase === "semifinal").map(enrich),
        final: allMatches.filter((m) => m.phase === "final").map(enrich),
        third_place: allMatches.filter((m) => m.phase === "third_place").map(enrich),
      };
    }),
});

// ─── Match Router ──────────────────────────────────────────────────────────────

const matchRouter = router({
  updateScore: protectedProcedure
    .input(
      z.object({
        matchId: z.number(),
        homeScore: z.number().min(0),
        awayScore: z.number().min(0),
        homePenalties: z.number().optional(),
        awayPenalties: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const match = await getMatchById(input.matchId);
      if (!match) throw new TRPCError({ code: "NOT_FOUND", message: "Partida não encontrada" });
      
      await updateMatchScore(input.matchId, input.homeScore, input.awayScore, 
        input.homePenalties !== undefined ? { home: input.homePenalties, away: input.awayPenalties! } : undefined
      );

      // If final match finished, set champion
      if (match.phase === "final") {
        const hS = input.homeScore + (input.homePenalties ?? 0);
        const aS = input.awayScore + (input.awayPenalties ?? 0);
        const winner = hS >= aS ? match.homeTeamId : match.awayTeamId;
        const teamList = await getTeamsByTournament(match.tournamentId);
        const championTeam = teamList.find((t) => t.id === winner);
        await updateTournamentStatus(match.tournamentId, "finished", championTeam?.name);
      }
      return { ok: true };
    }),

  updateDetails: protectedProcedure
    .input(
      z.object({
        matchId: z.number(),
        matchDate: z.string().optional(),
        matchTime: z.string().optional(),
        location: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const match = await getMatchById(input.matchId);
      if (!match) throw new TRPCError({ code: "NOT_FOUND", message: "Partida não encontrada" });

      await updateMatchDetails(input.matchId, input.matchDate, input.matchTime, input.location);
      return { ok: true };
    }),

  resetScore: protectedProcedure
    .input(z.object({ matchId: z.number() }))
    .mutation(async ({ input }) => {
      const match = await getMatchById(input.matchId);
      if (!match) throw new TRPCError({ code: "NOT_FOUND", message: "Partida não encontrada" });

      await resetMatchScore(input.matchId);

      // Se era a final, desfaz o campeão e volta o status do torneio para "final"
      if (match.phase === "final") {
        await updateTournamentStatus(match.tournamentId, "final");
      }

      return { ok: true };
    }),
});

// ─── Seed Router ───────────────────────────────────────────────────────────────

const seedRouter = router({
  seedExample: protectedProcedure.mutation(async () => {
    const tournamentId = await createTournament(1, "Sub-9 MASC", "Sub-9 Masculino", { groupCount: 1 });
    for (const team of DEFAULT_TEAMS) {
      await createTeam(tournamentId, team.name, team.shortName, team.color, "A");
    }
    return { id: tournamentId };
  }),

  checkAndSeed: publicProcedure.mutation(async () => {
    const all = await getAllTournaments();
    if (all.length === 0) {
      const tournamentId = await createTournament(1, "Sub-9 MASC", "Sub-9 Masculino", { groupCount: 1 });
      for (const team of DEFAULT_TEAMS) {
        await createTeam(tournamentId, team.name, team.shortName, team.color, "A");
      }
      return { seeded: true, tournamentId };
    }
    return { seeded: false };
  }),
});

// ─── App Router ────────────────────────────────────────────────────────────────

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  portal: portalRouter,
  tournament: tournamentRouter,
  match: matchRouter,
  seed: seedRouter,
});

export type AppRouter = typeof appRouter;

