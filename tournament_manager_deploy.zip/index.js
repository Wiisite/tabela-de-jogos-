var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// drizzle/schema.ts
var schema_exports = {};
__export(schema_exports, {
  matches: () => matches,
  portals: () => portals,
  teams: () => teams,
  tournaments: () => tournaments,
  users: () => users
});
import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  longtext,
  timestamp,
  varchar
} from "drizzle-orm/mysql-core";
var users, portals, tournaments, teams, matches;
var init_schema = __esm({
  "drizzle/schema.ts"() {
    "use strict";
    users = mysqlTable("users", {
      id: int("id").autoincrement().primaryKey(),
      openId: varchar("openId", { length: 64 }).notNull().unique(),
      name: text("name"),
      email: varchar("email", { length: 320 }),
      loginMethod: varchar("loginMethod", { length: 64 }),
      role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
      password: text("password"),
      portalId: int("portalId"),
      // Opcional: vincula um admin a um portal específico
      createdAt: timestamp("createdAt").defaultNow().notNull(),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
      lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull()
    });
    portals = mysqlTable("portals", {
      id: int("id").autoincrement().primaryKey(),
      name: varchar("name", { length: 255 }).notNull(),
      slug: varchar("slug", { length: 100 }).notNull().unique(),
      logo: longtext("logo"),
      primaryColor: varchar("primaryColor", { length: 7 }).default("#1e3a8a").notNull(),
      secondaryColor: varchar("secondaryColor", { length: 7 }).default("#f59e0b").notNull(),
      banner: longtext("banner"),
      fontFamily: varchar("fontFamily", { length: 100 }).default("Inter").notNull(),
      adminPassword: varchar("adminPassword", { length: 255 }),
      createdAt: timestamp("createdAt").defaultNow().notNull(),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
    });
    tournaments = mysqlTable("tournaments", {
      id: int("id").autoincrement().primaryKey(),
      portalId: int("portalId").notNull().default(1),
      name: varchar("name", { length: 255 }).notNull(),
      category: varchar("category", { length: 100 }).notNull().default("Geral"),
      status: mysqlEnum("status", ["pending", "group_stage", "semifinals", "final", "finished"]).default("pending").notNull(),
      champion: varchar("champion", { length: 255 }),
      // Novas configurações profissionais
      sport: mysqlEnum("sport", ["football", "basketball", "volleyball", "handball", "futsal"]).default("football").notNull(),
      groupCount: int("groupCount").default(1).notNull(),
      winPoints: int("winPoints").default(3).notNull(),
      drawPoints: int("drawPoints").default(1).notNull(),
      lossPoints: int("lossPoints").default(0).notNull(),
      isDoubleRound: int("isDoubleRound").default(0).notNull(),
      // 0=false, 1=true
      slider: longtext("slider"),
      // JSON array of base64 images
      sponsors: longtext("sponsors"),
      // JSON array of { name, logo }
      createdAt: timestamp("createdAt").defaultNow().notNull(),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
    });
    teams = mysqlTable("teams", {
      id: int("id").autoincrement().primaryKey(),
      tournamentId: int("tournamentId").notNull(),
      name: varchar("name", { length: 255 }).notNull(),
      shortName: varchar("shortName", { length: 10 }).notNull(),
      color: varchar("color", { length: 7 }).notNull().default("#1e40af"),
      logo: longtext("logo"),
      groupName: varchar("groupName", { length: 10 }).notNull().default("A"),
      createdAt: timestamp("createdAt").defaultNow().notNull()
    });
    matches = mysqlTable("matches", {
      id: int("id").autoincrement().primaryKey(),
      tournamentId: int("tournamentId").notNull(),
      phase: mysqlEnum("phase", ["group", "semifinal", "final", "third_place"]).notNull(),
      round: int("round").default(1).notNull(),
      homeTeamId: int("homeTeamId").notNull(),
      awayTeamId: int("awayTeamId").notNull(),
      homeScore: int("homeScore"),
      awayScore: int("awayScore"),
      homePenalties: int("homePenalties"),
      awayPenalties: int("awayPenalties"),
      matchDate: varchar("matchDate", { length: 50 }),
      matchTime: varchar("matchTime", { length: 50 }),
      location: varchar("location", { length: 255 }),
      status: mysqlEnum("status", ["scheduled", "finished"]).default("scheduled").notNull(),
      createdAt: timestamp("createdAt").defaultNow().notNull(),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
    });
  }
});

// server/_core/env.ts
var ENV;
var init_env = __esm({
  "server/_core/env.ts"() {
    "use strict";
    ENV = {
      appId: process.env.VITE_APP_ID ?? "",
      cookieSecret: process.env.JWT_SECRET ?? "",
      databaseUrl: process.env.DATABASE_URL ?? "",
      oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "",
      ownerOpenId: process.env.OWNER_OPEN_ID ?? "",
      isProduction: process.env.NODE_ENV === "production",
      forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? "",
      forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? "",
      adminPassword: process.env.ADMIN_PASSWORD ?? "admin123"
    };
  }
});

// server/db.ts
var db_exports = {};
__export(db_exports, {
  createMatch: () => createMatch,
  createPortal: () => createPortal,
  createTeam: () => createTeam,
  createTournament: () => createTournament,
  deleteMatchesByTournament: () => deleteMatchesByTournament,
  deletePortal: () => deletePortal,
  deleteTeam: () => deleteTeam,
  deleteTournament: () => deleteTournament,
  getAllPortals: () => getAllPortals,
  getAllTournaments: () => getAllTournaments,
  getDb: () => getDb,
  getGlobalStats: () => getGlobalStats,
  getMatchById: () => getMatchById,
  getMatchesByPhase: () => getMatchesByPhase,
  getMatchesByTournament: () => getMatchesByTournament,
  getPortalBySlug: () => getPortalBySlug,
  getTeamsByTournament: () => getTeamsByTournament,
  getTournamentById: () => getTournamentById,
  getUserByEmail: () => getUserByEmail,
  getUserByOpenId: () => getUserByOpenId,
  resetMatchScore: () => resetMatchScore,
  updateMatchDetails: () => updateMatchDetails,
  updateMatchScore: () => updateMatchScore,
  updatePortal: () => updatePortal,
  updateTeam: () => updateTeam,
  updateTournament: () => updateTournament,
  updateTournamentStatus: () => updateTournamentStatus,
  upsertUser: () => upsertUser
});
import { and, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
      console.log("[Database] Initialized successfully.");
    } catch (error) {
      console.error("[Database] Failed to connect:", error);
      _db = null;
    }
  } else if (!_db) {
    console.warn("[Database] DATABASE_URL is missing!");
  }
  return _db;
}
async function upsertUser(user) {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values = { openId: user.openId };
  const updateSet = {};
  const textFields = ["name", "email", "loginMethod"];
  const assignNullable = (field) => {
    const value = user[field];
    if (value === void 0) return;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  };
  textFields.forEach(assignNullable);
  if (user.lastSignedIn !== void 0) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== void 0) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = /* @__PURE__ */ new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = /* @__PURE__ */ new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}
async function getUserByOpenId(openId) {
  const db = await getDb();
  if (!db) return void 0;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : void 0;
}
async function getUserByEmail(email) {
  const db = await getDb();
  if (!db) return void 0;
  const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
  return result.length > 0 ? result[0] : void 0;
}
async function getAllPortals() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(portals).orderBy(portals.name);
}
async function getPortalBySlug(slug) {
  const db = await getDb();
  if (!db) return void 0;
  const result = await db.select().from(portals).where(eq(portals.slug, slug)).limit(1);
  return result[0];
}
async function createPortal(data) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(portals).values({
    name: data.name,
    slug: data.slug,
    logo: data.logo ?? null,
    primaryColor: data.primaryColor ?? "#1e3a8a",
    secondaryColor: data.secondaryColor ?? "#f59e0b",
    adminPassword: data.adminPassword ?? null
  });
  return result[0].insertId;
}
async function deletePortal(id) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.delete(portals).where(eq(portals.id, id));
}
async function updatePortal(id, data) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(portals).set(data).where(eq(portals.id, id));
}
async function getAllTournaments(portalId) {
  const db = await getDb();
  if (!db) return [];
  if (portalId) {
    return db.select().from(tournaments).where(eq(tournaments.portalId, portalId)).orderBy(tournaments.createdAt);
  }
  return db.select().from(tournaments).orderBy(tournaments.createdAt);
}
async function getTournamentById(id) {
  const db = await getDb();
  if (!db) return void 0;
  const result = await db.select().from(tournaments).where(eq(tournaments.id, id)).limit(1);
  return result[0];
}
async function createTournament(portalId, name, category, config = {}) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(tournaments).values({
    portalId,
    name,
    category,
    status: "pending",
    sport: config.sport ?? "football",
    groupCount: config.groupCount ?? 1,
    winPoints: config.winPoints ?? 3,
    drawPoints: config.drawPoints ?? 1,
    lossPoints: config.lossPoints ?? 0,
    isDoubleRound: config.isDoubleRound ? 1 : 0,
    slider: config.slider ?? null,
    sponsors: config.sponsors ?? null
  });
  return result[0].insertId;
}
async function updateTournamentStatus(id, status, champion) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(tournaments).set({ status, ...champion !== void 0 ? { champion } : {} }).where(eq(tournaments.id, id));
}
async function updateTournament(id, data) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const updateSet = { ...data };
  if (data.isDoubleRound !== void 0) {
    updateSet.isDoubleRound = data.isDoubleRound ? 1 : 0;
  }
  await db.update(tournaments).set(updateSet).where(eq(tournaments.id, id));
}
async function deleteTournament(id) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.delete(matches).where(eq(matches.tournamentId, id));
  await db.delete(teams).where(eq(teams.tournamentId, id));
  await db.delete(tournaments).where(eq(tournaments.id, id));
}
async function getTeamsByTournament(tournamentId) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(teams).where(eq(teams.tournamentId, tournamentId));
}
async function createTeam(tournamentId, name, shortName, color, groupName = "A", logo) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.insert(teams).values({ tournamentId, name, shortName, color, groupName, logo });
}
async function updateTeam(id, data) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(teams).set(data).where(eq(teams.id, id));
}
async function deleteTeam(id) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.delete(teams).where(eq(teams.id, id));
}
async function getMatchesByTournament(tournamentId) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(matches).where(eq(matches.tournamentId, tournamentId));
}
async function getMatchesByPhase(tournamentId, phase) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(matches).where(and(eq(matches.tournamentId, tournamentId), eq(matches.phase, phase)));
}
async function createMatch(tournamentId, phase, homeTeamId, awayTeamId, round) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.insert(matches).values({ tournamentId, phase, homeTeamId, awayTeamId, round });
}
async function deleteMatchesByTournament(tournamentId, phase) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const condition = phase ? and(eq(matches.tournamentId, tournamentId), eq(matches.phase, phase)) : eq(matches.tournamentId, tournamentId);
  await db.delete(matches).where(condition);
}
async function updateMatchScore(matchId, homeScore, awayScore, penalties) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(matches).set({
    homeScore,
    awayScore,
    homePenalties: penalties?.home ?? null,
    awayPenalties: penalties?.away ?? null,
    status: "finished"
  }).where(eq(matches.id, matchId));
}
async function updateMatchDetails(matchId, matchDate, matchTime, location) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(matches).set({
    ...matchDate !== void 0 ? { matchDate } : {},
    ...matchTime !== void 0 ? { matchTime } : {},
    ...location !== void 0 ? { location } : {}
  }).where(eq(matches.id, matchId));
}
async function resetMatchScore(matchId) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(matches).set({
    homeScore: null,
    awayScore: null,
    homePenalties: null,
    awayPenalties: null,
    status: "scheduled"
  }).where(eq(matches.id, matchId));
}
async function getMatchById(matchId) {
  const db = await getDb();
  if (!db) return void 0;
  const result = await db.select().from(matches).where(eq(matches.id, matchId)).limit(1);
  return result[0];
}
async function getGlobalStats() {
  const db = await getDb();
  if (!db) return { tournaments: 0, teams: 0, matches: 0 };
  const tCount = await db.select().from(tournaments);
  const tmCount = await db.select().from(teams);
  const mCount = await db.select().from(matches);
  return {
    tournaments: tCount.length,
    teams: tmCount.length,
    matches: mCount.length
  };
}
var _db;
var init_db = __esm({
  "server/db.ts"() {
    "use strict";
    init_schema();
    init_env();
    _db = null;
  }
});

// server/_core/index.ts
import "dotenv/config";
import express2 from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";

// shared/const.ts
var COOKIE_NAME = "app_session_id";
var ONE_YEAR_MS = 1e3 * 60 * 60 * 24 * 365;
var AXIOS_TIMEOUT_MS = 3e4;
var UNAUTHED_ERR_MSG = "Please login (10001)";
var NOT_ADMIN_ERR_MSG = "You do not have required permission (10002)";

// server/_core/oauth.ts
init_db();

// server/_core/cookies.ts
function isSecureRequest(req) {
  if (req.protocol === "https") return true;
  const forwardedProto = req.headers["x-forwarded-proto"];
  if (!forwardedProto) return false;
  const protoList = Array.isArray(forwardedProto) ? forwardedProto : forwardedProto.split(",");
  return protoList.some((proto) => proto.trim().toLowerCase() === "https");
}
function getSessionCookieOptions(req) {
  return {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: isSecureRequest(req)
  };
}

// shared/_core/errors.ts
var HttpError = class extends Error {
  constructor(statusCode, message) {
    super(message);
    this.statusCode = statusCode;
    this.name = "HttpError";
  }
};
var ForbiddenError = (msg) => new HttpError(403, msg);

// server/_core/sdk.ts
init_db();
init_env();
import axios from "axios";
import { parse as parseCookieHeader } from "cookie";
import { SignJWT, jwtVerify } from "jose";
var isNonEmptyString = (value) => typeof value === "string" && value.length > 0;
var EXCHANGE_TOKEN_PATH = `/webdev.v1.WebDevAuthPublicService/ExchangeToken`;
var GET_USER_INFO_PATH = `/webdev.v1.WebDevAuthPublicService/GetUserInfo`;
var GET_USER_INFO_WITH_JWT_PATH = `/webdev.v1.WebDevAuthPublicService/GetUserInfoWithJwt`;
var OAuthService = class {
  constructor(client) {
    this.client = client;
    console.log("[OAuth] Initialized with baseURL:", ENV.oAuthServerUrl);
    if (!ENV.oAuthServerUrl) {
      console.info(
        "[OAuth] INFO: OAUTH_SERVER_URL is not configured. OAuth logins will be disabled."
      );
    }
  }
  decodeState(state) {
    const redirectUri = atob(state);
    return redirectUri;
  }
  async getTokenByCode(code, state) {
    const payload = {
      clientId: ENV.appId,
      grantType: "authorization_code",
      code,
      redirectUri: this.decodeState(state)
    };
    const { data } = await this.client.post(
      EXCHANGE_TOKEN_PATH,
      payload
    );
    return data;
  }
  async getUserInfoByToken(token) {
    const { data } = await this.client.post(
      GET_USER_INFO_PATH,
      {
        accessToken: token.accessToken
      }
    );
    return data;
  }
};
var createOAuthHttpClient = () => axios.create({
  baseURL: ENV.oAuthServerUrl,
  timeout: AXIOS_TIMEOUT_MS
});
var SDKServer = class {
  client;
  oauthService;
  constructor(client = createOAuthHttpClient()) {
    this.client = client;
    this.oauthService = new OAuthService(this.client);
  }
  deriveLoginMethod(platforms, fallback) {
    if (fallback && fallback.length > 0) return fallback;
    if (!Array.isArray(platforms) || platforms.length === 0) return null;
    const set = new Set(
      platforms.filter((p) => typeof p === "string")
    );
    if (set.has("REGISTERED_PLATFORM_EMAIL")) return "email";
    if (set.has("REGISTERED_PLATFORM_GOOGLE")) return "google";
    if (set.has("REGISTERED_PLATFORM_APPLE")) return "apple";
    if (set.has("REGISTERED_PLATFORM_MICROSOFT") || set.has("REGISTERED_PLATFORM_AZURE"))
      return "microsoft";
    if (set.has("REGISTERED_PLATFORM_GITHUB")) return "github";
    const first = Array.from(set)[0];
    return first ? first.toLowerCase() : null;
  }
  /**
   * Exchange OAuth authorization code for access token
   * @example
   * const tokenResponse = await sdk.exchangeCodeForToken(code, state);
   */
  async exchangeCodeForToken(code, state) {
    return this.oauthService.getTokenByCode(code, state);
  }
  /**
   * Get user information using access token
   * @example
   * const userInfo = await sdk.getUserInfo(tokenResponse.accessToken);
   */
  async getUserInfo(accessToken) {
    const data = await this.oauthService.getUserInfoByToken({
      accessToken
    });
    const loginMethod = this.deriveLoginMethod(
      data?.platforms,
      data?.platform ?? data.platform ?? null
    );
    return {
      ...data,
      platform: loginMethod,
      loginMethod
    };
  }
  parseCookies(cookieHeader) {
    if (!cookieHeader) {
      return /* @__PURE__ */ new Map();
    }
    const parsed = parseCookieHeader(cookieHeader);
    return new Map(Object.entries(parsed));
  }
  getSessionSecret() {
    const secret = ENV.cookieSecret;
    return new TextEncoder().encode(secret);
  }
  /**
   * Create a session token for a Manus user openId
   * @example
   * const sessionToken = await sdk.createSessionToken(userInfo.openId);
   */
  async createSessionToken(openId, options = {}) {
    return this.signSession(
      {
        openId,
        appId: ENV.appId,
        name: options.name || ""
      },
      options
    );
  }
  async signSession(payload, options = {}) {
    const issuedAt = Date.now();
    const expiresInMs = options.expiresInMs ?? ONE_YEAR_MS;
    const expirationSeconds = Math.floor((issuedAt + expiresInMs) / 1e3);
    const secretKey = this.getSessionSecret();
    return new SignJWT({
      openId: payload.openId,
      appId: payload.appId,
      name: payload.name
    }).setProtectedHeader({ alg: "HS256", typ: "JWT" }).setExpirationTime(expirationSeconds).sign(secretKey);
  }
  async verifySession(cookieValue) {
    if (!cookieValue) {
      console.warn("[Auth] Missing session cookie");
      return null;
    }
    try {
      const secretKey = this.getSessionSecret();
      const { payload } = await jwtVerify(cookieValue, secretKey, {
        algorithms: ["HS256"]
      });
      const { openId, appId, name } = payload;
      if (!isNonEmptyString(openId) || !isNonEmptyString(appId) && appId !== "admin_local_app" || !isNonEmptyString(name)) {
        console.warn("[Auth] Session payload missing required fields");
        return null;
      }
      return {
        openId,
        appId,
        name
      };
    } catch (error) {
      console.warn("[Auth] Session verification failed", String(error));
      return null;
    }
  }
  async getUserInfoWithJwt(jwtToken) {
    const payload = {
      jwtToken,
      projectId: ENV.appId
    };
    const { data } = await this.client.post(
      GET_USER_INFO_WITH_JWT_PATH,
      payload
    );
    const loginMethod = this.deriveLoginMethod(
      data?.platforms,
      data?.platform ?? data.platform ?? null
    );
    return {
      ...data,
      platform: loginMethod,
      loginMethod
    };
  }
  async authenticateRequest(req) {
    const cookies = this.parseCookies(req.headers.cookie);
    const sessionCookie = cookies.get(COOKIE_NAME);
    const session = await this.verifySession(sessionCookie);
    if (!session) {
      throw ForbiddenError("Invalid session cookie");
    }
    const sessionUserId = session.openId;
    const signedInAt = /* @__PURE__ */ new Date();
    let user = await getUserByOpenId(sessionUserId);
    if (!user) {
      try {
        const userInfo = await this.getUserInfoWithJwt(sessionCookie ?? "");
        await upsertUser({
          openId: userInfo.openId,
          name: userInfo.name || null,
          email: userInfo.email ?? null,
          loginMethod: userInfo.loginMethod ?? userInfo.platform ?? null,
          lastSignedIn: signedInAt
        });
        user = await getUserByOpenId(userInfo.openId);
      } catch (error) {
        console.error("[Auth] Failed to sync user from OAuth:", error);
        throw ForbiddenError("Failed to sync user info");
      }
    }
    if (!user) {
      throw ForbiddenError("User not found");
    }
    await upsertUser({
      openId: user.openId,
      lastSignedIn: signedInAt
    });
    return user;
  }
};
var sdk = new SDKServer();

// server/_core/oauth.ts
function getQueryParam(req, key) {
  const value = req.query[key];
  return typeof value === "string" ? value : void 0;
}
function registerOAuthRoutes(app) {
  app.get("/api/oauth/callback", async (req, res) => {
    const code = getQueryParam(req, "code");
    const state = getQueryParam(req, "state");
    if (!code || !state) {
      res.status(400).json({ error: "code and state are required" });
      return;
    }
    try {
      const tokenResponse = await sdk.exchangeCodeForToken(code, state);
      const userInfo = await sdk.getUserInfo(tokenResponse.accessToken);
      if (!userInfo.openId) {
        res.status(400).json({ error: "openId missing from user info" });
        return;
      }
      await upsertUser({
        openId: userInfo.openId,
        name: userInfo.name || null,
        email: userInfo.email ?? null,
        loginMethod: userInfo.loginMethod ?? userInfo.platform ?? null,
        lastSignedIn: /* @__PURE__ */ new Date()
      });
      const sessionToken = await sdk.createSessionToken(userInfo.openId, {
        name: userInfo.name || "",
        expiresInMs: ONE_YEAR_MS
      });
      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });
      res.redirect(302, "/");
    } catch (error) {
      console.error("[OAuth] Callback failed", error);
      res.status(500).json({ error: "OAuth callback failed" });
    }
  });
}

// server/routers.ts
init_db();
import { TRPCError as TRPCError3 } from "@trpc/server";
import { z as z2 } from "zod";

// server/_core/systemRouter.ts
import { z } from "zod";

// server/_core/notification.ts
init_env();
import { TRPCError } from "@trpc/server";
var TITLE_MAX_LENGTH = 1200;
var CONTENT_MAX_LENGTH = 2e4;
var trimValue = (value) => value.trim();
var isNonEmptyString2 = (value) => typeof value === "string" && value.trim().length > 0;
var buildEndpointUrl = (baseUrl) => {
  const normalizedBase = baseUrl.endsWith("/") ? baseUrl : `${baseUrl}/`;
  return new URL(
    "webdevtoken.v1.WebDevService/SendNotification",
    normalizedBase
  ).toString();
};
var validatePayload = (input) => {
  if (!isNonEmptyString2(input.title)) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "Notification title is required."
    });
  }
  if (!isNonEmptyString2(input.content)) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "Notification content is required."
    });
  }
  const title = trimValue(input.title);
  const content = trimValue(input.content);
  if (title.length > TITLE_MAX_LENGTH) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: `Notification title must be at most ${TITLE_MAX_LENGTH} characters.`
    });
  }
  if (content.length > CONTENT_MAX_LENGTH) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: `Notification content must be at most ${CONTENT_MAX_LENGTH} characters.`
    });
  }
  return { title, content };
};
async function notifyOwner(payload) {
  const { title, content } = validatePayload(payload);
  if (!ENV.forgeApiUrl) {
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "Notification service URL is not configured."
    });
  }
  if (!ENV.forgeApiKey) {
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "Notification service API key is not configured."
    });
  }
  const endpoint = buildEndpointUrl(ENV.forgeApiUrl);
  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        accept: "application/json",
        authorization: `Bearer ${ENV.forgeApiKey}`,
        "content-type": "application/json",
        "connect-protocol-version": "1"
      },
      body: JSON.stringify({ title, content })
    });
    if (!response.ok) {
      const detail = await response.text().catch(() => "");
      console.warn(
        `[Notification] Failed to notify owner (${response.status} ${response.statusText})${detail ? `: ${detail}` : ""}`
      );
      return false;
    }
    return true;
  } catch (error) {
    console.warn("[Notification] Error calling notification service:", error);
    return false;
  }
}

// server/_core/trpc.ts
import { initTRPC, TRPCError as TRPCError2 } from "@trpc/server";
import superjson from "superjson";
var t = initTRPC.context().create({
  transformer: superjson
});
var router = t.router;
var publicProcedure = t.procedure;
var requireUser = t.middleware(async (opts) => {
  const { ctx, next } = opts;
  if (!ctx.user) {
    throw new TRPCError2({ code: "UNAUTHORIZED", message: UNAUTHED_ERR_MSG });
  }
  return next({
    ctx: {
      ...ctx,
      user: ctx.user
    }
  });
});
var protectedProcedure = t.procedure.use(requireUser);
var adminProcedure = t.procedure.use(
  t.middleware(async (opts) => {
    const { ctx, next } = opts;
    if (!ctx.user || ctx.user.role !== "admin") {
      throw new TRPCError2({ code: "FORBIDDEN", message: NOT_ADMIN_ERR_MSG });
    }
    return next({
      ctx: {
        ...ctx,
        user: ctx.user
      }
    });
  })
);

// server/_core/systemRouter.ts
var systemRouter = router({
  health: publicProcedure.input(
    z.object({
      timestamp: z.number().min(0, "timestamp cannot be negative")
    })
  ).query(() => ({
    ok: true
  })),
  notifyOwner: adminProcedure.input(
    z.object({
      title: z.string().min(1, "title is required"),
      content: z.string().min(1, "content is required")
    })
  ).mutation(async ({ input }) => {
    const delivered = await notifyOwner(input);
    return {
      success: delivered
    };
  })
});

// server/routers.ts
function generateCircleSchedule(teamIds) {
  const list = [...teamIds];
  const isOdd = list.length % 2 !== 0;
  if (isOdd) list.push(-1);
  const n = list.length;
  const numRounds = n - 1;
  const halfSize = n / 2;
  const result = [];
  const fixed = list[0];
  const rotating = list.slice(1);
  for (let round = 0; round < numRounds; round++) {
    const current = [fixed, ...rotating];
    for (let i = 0; i < halfSize; i++) {
      const home = current[i];
      const away = current[n - 1 - i];
      if (home !== -1 && away !== -1) {
        result.push({ home, away, round: round + 1 });
      }
    }
    const last = rotating.pop();
    rotating.unshift(last);
  }
  return result;
}
function computeStandings(teamList, groupMatches, pointsConfig = { win: 3, draw: 1, loss: 0 }) {
  const map = /* @__PURE__ */ new Map();
  for (const t2 of teamList) {
    map.set(t2.id, {
      teamId: t2.id,
      teamName: t2.name,
      shortName: t2.shortName,
      color: t2.color,
      logo: t2.logo ?? null,
      groupName: t2.groupName,
      played: 0,
      won: 0,
      drawn: 0,
      lost: 0,
      goalsFor: 0,
      goalsAgainst: 0,
      goalDiff: 0,
      points: 0
    });
  }
  for (const m of groupMatches) {
    if (m.status !== "finished" || m.homeScore === null || m.awayScore === null) continue;
    const home = map.get(m.homeTeamId);
    const away = map.get(m.awayTeamId);
    if (!home || !away) continue;
    home.played++;
    away.played++;
    home.goalsFor += m.homeScore;
    home.goalsAgainst += m.awayScore;
    away.goalsFor += m.awayScore;
    away.goalsAgainst += m.homeScore;
    if (m.homeScore > m.awayScore) {
      home.won++;
      home.points += pointsConfig.win;
      away.lost++;
      away.points += pointsConfig.loss;
    } else if (m.homeScore < m.awayScore) {
      away.won++;
      away.points += pointsConfig.win;
      home.lost++;
      home.points += pointsConfig.loss;
    } else {
      home.drawn++;
      away.drawn++;
      home.points += pointsConfig.draw;
      away.points += pointsConfig.draw;
    }
  }
  const entries = Array.from(map.values());
  for (const entry of entries) {
    entry.goalDiff = entry.goalsFor - entry.goalsAgainst;
  }
  return entries.sort((a, b) => {
    if (b.points !== a.points) return b.points - a.points;
    if (b.won !== a.won) return b.won - a.won;
    if (b.goalDiff !== a.goalDiff) return b.goalDiff - a.goalDiff;
    if (b.goalsFor !== a.goalsFor) return b.goalsFor - a.goalsFor;
    const h2hMatch = groupMatches.find(
      (m) => m.status === "finished" && (m.homeTeamId === a.teamId && m.awayTeamId === b.teamId || m.homeTeamId === b.teamId && m.awayTeamId === a.teamId)
    );
    if (h2hMatch && h2hMatch.homeScore !== h2hMatch.awayScore) {
      const aScore = h2hMatch.homeTeamId === a.teamId ? h2hMatch.homeScore : h2hMatch.awayScore;
      const bScore = h2hMatch.homeTeamId === b.teamId ? h2hMatch.homeScore : h2hMatch.awayScore;
      return bScore - aScore;
    }
    return 0;
  });
}
var DEFAULT_TEAMS = [
  { name: "Col\xE9gio Beryon", shortName: "BRY", color: "#1e3a8a" },
  { name: "Col\xE9gio Educar", shortName: "EDU", color: "#166534" },
  { name: "Col\xE9gio Santa Rita", shortName: "CSR", color: "#7c3aed" },
  { name: "Col\xE9gio Marconi", shortName: "MCN", color: "#b91c1c" },
  { name: "Col\xE9gio Parthenon", shortName: "PTH", color: "#d97706" },
  { name: "Col\xE9gio Canada", shortName: "CDA", color: "#0e7490" }
];
var portalRouter = router({
  list: publicProcedure.query(async () => {
    return getAllPortals();
  }),
  getBySlug: publicProcedure.input(z2.object({ slug: z2.string() })).query(async ({ input }) => {
    const portal = await getPortalBySlug(input.slug);
    if (!portal) throw new TRPCError3({ code: "NOT_FOUND", message: "Portal n\xE3o encontrado" });
    return portal;
  }),
  create: protectedProcedure.input(
    z2.object({
      name: z2.string().min(1),
      slug: z2.string().min(1),
      logo: z2.string().nullable().optional(),
      primaryColor: z2.string().optional(),
      secondaryColor: z2.string().optional(),
      adminPassword: z2.string().optional()
    })
  ).mutation(async ({ input }) => {
    const existing = await getPortalBySlug(input.slug);
    if (existing) throw new TRPCError3({ code: "BAD_REQUEST", message: "Este slug j\xE1 est\xE1 em uso" });
    const id = await createPortal(input);
    return { id };
  }),
  delete: protectedProcedure.input(z2.object({ id: z2.number() })).mutation(async ({ input }) => {
    await deletePortal(input.id);
    return { ok: true };
  }),
  update: protectedProcedure.input(
    z2.object({
      id: z2.number(),
      name: z2.string().optional(),
      logo: z2.string().nullable().optional(),
      banner: z2.string().nullable().optional(),
      primaryColor: z2.string().optional(),
      secondaryColor: z2.string().optional(),
      fontFamily: z2.string().optional(),
      adminPassword: z2.string().optional()
    })
  ).mutation(async ({ input }) => {
    await updatePortal(input.id, input);
    return { ok: true };
  })
});
var tournamentRouter = router({
  list: publicProcedure.input(z2.object({ portalId: z2.number().optional() }).optional()).query(async ({ input }) => {
    return getAllTournaments(input?.portalId);
  }),
  getGlobalStats: publicProcedure.query(async () => {
    const stats = await Promise.resolve().then(() => (init_db(), db_exports)).then((db) => db.getGlobalStats());
    return stats;
  }),
  getById: publicProcedure.input(z2.object({ id: z2.number() })).query(async ({ input }) => {
    const tournament = await getTournamentById(input.id);
    if (!tournament) throw new TRPCError3({ code: "NOT_FOUND", message: "Torneio n\xE3o encontrado" });
    const teamList = await getTeamsByTournament(input.id);
    const matchList = await getMatchesByTournament(input.id);
    return { tournament, teams: teamList, matches: matchList };
  }),
  delete: protectedProcedure.input(z2.object({ id: z2.number() })).mutation(async ({ input }) => {
    const tournament = await getTournamentById(input.id);
    if (!tournament) throw new TRPCError3({ code: "NOT_FOUND", message: "Torneio n\xE3o encontrado" });
    await deleteTournament(input.id);
    return { ok: true };
  }),
  create: protectedProcedure.input(
    z2.object({
      portalId: z2.number().default(1),
      name: z2.string().min(1),
      category: z2.string().min(1),
      sport: z2.enum(["football", "basketball", "volleyball", "handball", "futsal"]).default("football"),
      groupCount: z2.number().min(1).max(4).default(1),
      winPoints: z2.number().default(3),
      drawPoints: z2.number().default(1),
      lossPoints: z2.number().default(0),
      isDoubleRound: z2.boolean().default(false),
      teams: z2.array(
        z2.object({
          name: z2.string().min(1),
          shortName: z2.string().min(1).max(10),
          color: z2.string().default("#1e40af"),
          groupName: z2.string().default("A"),
          logo: z2.string().nullable().optional()
        })
      ).min(2),
      slider: z2.string().nullable().optional(),
      sponsors: z2.string().nullable().optional()
    })
  ).mutation(async ({ input, ctx }) => {
    const portalId = ctx.user?.role === "admin" && ctx.user.portalId ? ctx.user.portalId : input.portalId;
    const tournamentId = await createTournament(portalId, input.name, input.category, {
      sport: input.sport,
      groupCount: input.groupCount,
      winPoints: input.winPoints,
      drawPoints: input.drawPoints,
      lossPoints: input.lossPoints,
      isDoubleRound: input.isDoubleRound,
      slider: input.slider,
      sponsors: input.sponsors
    });
    for (const t2 of input.teams) {
      await createTeam(tournamentId, t2.name, t2.shortName, t2.color, t2.groupName, t2.logo);
    }
    return { id: tournamentId };
  }),
  update: protectedProcedure.input(
    z2.object({
      id: z2.number(),
      name: z2.string().optional(),
      category: z2.string().optional(),
      sport: z2.enum(["football", "basketball", "volleyball", "handball", "futsal"]).optional(),
      groupCount: z2.number().min(1).max(4).optional(),
      winPoints: z2.number().optional(),
      drawPoints: z2.number().optional(),
      lossPoints: z2.number().optional(),
      isDoubleRound: z2.boolean().optional(),
      champion: z2.string().nullable().optional(),
      slider: z2.string().nullable().optional(),
      sponsors: z2.string().nullable().optional(),
      teams: z2.array(
        z2.object({
          id: z2.number().optional(),
          // If provided, update; else create
          name: z2.string().min(1),
          shortName: z2.string().min(1).max(10),
          color: z2.string(),
          groupName: z2.string().default("A"),
          logo: z2.string().nullable().optional()
        })
      ).optional()
    })
  ).mutation(async ({ input }) => {
    const { id, teams: inputTeams, ...updateData } = input;
    await updateTournament(id, updateData);
    if (inputTeams) {
      const existingTeams = await getTeamsByTournament(id);
      const existingIds = existingTeams.map((t2) => t2.id);
      const inputIds = inputTeams.map((t2) => t2.id).filter((tid) => !!tid);
      for (const et of existingTeams) {
        if (!inputIds.includes(et.id)) {
          await deleteTeam(et.id);
        }
      }
      for (const it of inputTeams) {
        if (it.id && existingIds.includes(it.id)) {
          await updateTeam(it.id, {
            name: it.name,
            shortName: it.shortName,
            color: it.color,
            groupName: it.groupName,
            logo: it.logo
          });
        } else {
          await createTeam(id, it.name, it.shortName, it.color, it.groupName, it.logo);
        }
      }
    }
    return { ok: true };
  }),
  generateGroupMatches: protectedProcedure.input(z2.object({ tournamentId: z2.number(), clearExisting: z2.boolean().default(false) })).mutation(async ({ input }) => {
    const tournament = await getTournamentById(input.tournamentId);
    if (!tournament) throw new TRPCError3({ code: "NOT_FOUND" });
    if (input.clearExisting) {
      await deleteMatchesByTournament(input.tournamentId, "group");
    } else {
      const existing = await getMatchesByPhase(input.tournamentId, "group");
      if (existing.length > 0) throw new TRPCError3({ code: "BAD_REQUEST", message: "Confrontos j\xE1 gerados" });
    }
    const teamList = await getTeamsByTournament(input.tournamentId);
    const groups = {};
    for (const t2 of teamList) {
      if (!groups[t2.groupName]) groups[t2.groupName] = [];
      groups[t2.groupName].push(t2);
    }
    for (const groupName in groups) {
      const groupTeams = groups[groupName];
      if (groupTeams.length < 2) continue;
      const turno = generateCircleSchedule(groupTeams.map((t2) => t2.id));
      for (const { home, away, round } of turno) {
        await createMatch(input.tournamentId, "group", home, away, round);
      }
      if (tournament.isDoubleRound) {
        const numTurnoRounds = turno.length > 0 ? Math.max(...turno.map((g) => g.round)) : 0;
        for (const { home, away, round } of turno) {
          await createMatch(input.tournamentId, "group", away, home, numTurnoRounds + round);
        }
      }
    }
    await updateTournamentStatus(input.tournamentId, "group_stage");
    return { ok: true };
  }),
  getStandings: publicProcedure.input(z2.object({ tournamentId: z2.number() })).query(async ({ input }) => {
    const tournament = await getTournamentById(input.tournamentId);
    if (!tournament) throw new TRPCError3({ code: "NOT_FOUND" });
    const teamList = await getTeamsByTournament(input.tournamentId);
    const groupMatches = await getMatchesByPhase(input.tournamentId, "group");
    const pointsConfig = {
      win: tournament.winPoints,
      draw: tournament.drawPoints,
      loss: tournament.lossPoints
    };
    const groups = Array.from(new Set(teamList.map((t2) => t2.groupName))).sort();
    const standingsByGroup = {};
    for (const g of groups) {
      const gTeams = teamList.filter((t2) => t2.groupName === g);
      const gMatches = groupMatches.filter((m) => {
        const home = gTeams.find((t2) => t2.id === m.homeTeamId);
        const away = gTeams.find((t2) => t2.id === m.awayTeamId);
        return !!home && !!away;
      });
      standingsByGroup[g] = computeStandings(gTeams, gMatches, pointsConfig);
    }
    return standingsByGroup;
  }),
  generateSemifinals: protectedProcedure.input(z2.object({ tournamentId: z2.number() })).mutation(async ({ input }) => {
    const tournament = await getTournamentById(input.tournamentId);
    if (!tournament) throw new TRPCError3({ code: "NOT_FOUND" });
    const teamList = await getTeamsByTournament(input.tournamentId);
    const groupMatches = await getMatchesByPhase(input.tournamentId, "group");
    const unfinished = groupMatches.filter((m) => m.status !== "finished");
    if (unfinished.length > 0)
      throw new TRPCError3({ code: "BAD_REQUEST", message: "Ainda h\xE1 partidas da fase de grupos em aberto" });
    const existing = await getMatchesByPhase(input.tournamentId, "semifinal");
    if (existing.length > 0) throw new TRPCError3({ code: "BAD_REQUEST", message: "Semifinais j\xE1 geradas" });
    const pointsConfig = { win: tournament.winPoints, draw: tournament.drawPoints, loss: tournament.lossPoints };
    if (tournament.groupCount === 1) {
      const standings = computeStandings(teamList, groupMatches, pointsConfig);
      if (standings.length < 4) throw new TRPCError3({ code: "BAD_REQUEST", message: "M\xEDnimo 4 equipes para semis" });
      await createMatch(input.tournamentId, "semifinal", standings[0].teamId, standings[3].teamId, 1);
      await createMatch(input.tournamentId, "semifinal", standings[1].teamId, standings[2].teamId, 2);
    } else if (tournament.groupCount === 2) {
      const sA = computeStandings(teamList.filter((t2) => t2.groupName === "A"), groupMatches, pointsConfig);
      const sB = computeStandings(teamList.filter((t2) => t2.groupName === "B"), groupMatches, pointsConfig);
      if (sA.length < 2 || sB.length < 2) throw new TRPCError3({ code: "BAD_REQUEST", message: "M\xEDnimo 2 equipes por grupo" });
      await createMatch(input.tournamentId, "semifinal", sA[0].teamId, sB[1].teamId, 1);
      await createMatch(input.tournamentId, "semifinal", sB[0].teamId, sA[1].teamId, 2);
    } else if (tournament.groupCount === 3) {
      const sA = computeStandings(teamList.filter((t2) => t2.groupName === "A"), groupMatches, pointsConfig);
      const sB = computeStandings(teamList.filter((t2) => t2.groupName === "B"), groupMatches, pointsConfig);
      const sC = computeStandings(teamList.filter((t2) => t2.groupName === "C"), groupMatches, pointsConfig);
      if (!sA[0] || !sB[0] || !sC[0]) throw new TRPCError3({ code: "BAD_REQUEST", message: "M\xEDnimo 1 equipe por grupo" });
      const runners = [sA[1], sB[1], sC[1]].filter(Boolean).sort((a, b) => {
        if (b.points !== a.points) return b.points - a.points;
        if (b.won !== a.won) return b.won - a.won;
        if (b.goalDiff !== a.goalDiff) return b.goalDiff - a.goalDiff;
        return b.goalsFor - a.goalsFor;
      });
      if (!runners[0]) throw new TRPCError3({ code: "BAD_REQUEST", message: "M\xEDnimo 2 equipes por grupo para gerar semis" });
      const bestRunner = runners[0];
      await createMatch(input.tournamentId, "semifinal", sA[0].teamId, bestRunner.teamId, 1);
      await createMatch(input.tournamentId, "semifinal", sB[0].teamId, sC[0].teamId, 2);
    } else if (tournament.groupCount === 4) {
      const sA = computeStandings(teamList.filter((t2) => t2.groupName === "A"), groupMatches, pointsConfig);
      const sB = computeStandings(teamList.filter((t2) => t2.groupName === "B"), groupMatches, pointsConfig);
      const sC = computeStandings(teamList.filter((t2) => t2.groupName === "C"), groupMatches, pointsConfig);
      const sD = computeStandings(teamList.filter((t2) => t2.groupName === "D"), groupMatches, pointsConfig);
      await createMatch(input.tournamentId, "semifinal", sA[0].teamId, sD[0].teamId, 1);
      await createMatch(input.tournamentId, "semifinal", sB[0].teamId, sC[0].teamId, 2);
    } else {
      throw new TRPCError3({ code: "BAD_REQUEST", message: "Formato de grupos n\xE3o suportado" });
    }
    await updateTournamentStatus(input.tournamentId, "semifinals");
    return { ok: true };
  }),
  generateFinal: protectedProcedure.input(z2.object({ tournamentId: z2.number() })).mutation(async ({ input }) => {
    const semis = await getMatchesByPhase(input.tournamentId, "semifinal");
    const unfinished = semis.filter((m) => m.status !== "finished");
    if (unfinished.length > 0)
      throw new TRPCError3({ code: "BAD_REQUEST", message: "Ainda h\xE1 semifinais em aberto" });
    const existing = await getMatchesByPhase(input.tournamentId, "final");
    if (existing.length > 0) throw new TRPCError3({ code: "BAD_REQUEST", message: "Final j\xE1 gerada" });
    const getWinnerAndLoser = (m) => {
      const hS = m.homeScore + (m.homePenalties ?? 0);
      const aS = m.awayScore + (m.awayPenalties ?? 0);
      if (hS > aS) return { winner: m.homeTeamId, loser: m.awayTeamId };
      return { winner: m.awayTeamId, loser: m.homeTeamId };
    };
    const semi1 = semis.find((m) => m.round === 1);
    const semi2 = semis.find((m) => m.round === 2);
    const res1 = getWinnerAndLoser(semi1);
    const res2 = getWinnerAndLoser(semi2);
    await createMatch(input.tournamentId, "final", res1.winner, res2.winner, 1);
    await createMatch(input.tournamentId, "third_place", res1.loser, res2.loser, 1);
    await updateTournamentStatus(input.tournamentId, "final");
    return { ok: true };
  }),
  getBracket: publicProcedure.input(z2.object({ tournamentId: z2.number() })).query(async ({ input }) => {
    const teamList = await getTeamsByTournament(input.tournamentId);
    const allMatches = await getMatchesByTournament(input.tournamentId);
    const teamMap = new Map(teamList.map((t2) => [t2.id, t2]));
    const enrich = (m) => ({
      ...m,
      homeTeam: teamMap.get(m.homeTeamId),
      awayTeam: teamMap.get(m.awayTeamId)
    });
    return {
      group: allMatches.filter((m) => m.phase === "group").map(enrich),
      semifinal: allMatches.filter((m) => m.phase === "semifinal").map(enrich),
      final: allMatches.filter((m) => m.phase === "final").map(enrich),
      third_place: allMatches.filter((m) => m.phase === "third_place").map(enrich)
    };
  })
});
var matchRouter = router({
  updateScore: protectedProcedure.input(
    z2.object({
      matchId: z2.number(),
      homeScore: z2.number().min(0),
      awayScore: z2.number().min(0),
      homePenalties: z2.number().optional(),
      awayPenalties: z2.number().optional()
    })
  ).mutation(async ({ input }) => {
    const match = await getMatchById(input.matchId);
    if (!match) throw new TRPCError3({ code: "NOT_FOUND", message: "Partida n\xE3o encontrada" });
    await updateMatchScore(
      input.matchId,
      input.homeScore,
      input.awayScore,
      input.homePenalties !== void 0 ? { home: input.homePenalties, away: input.awayPenalties } : void 0
    );
    if (match.phase === "final") {
      const hS = input.homeScore + (input.homePenalties ?? 0);
      const aS = input.awayScore + (input.awayPenalties ?? 0);
      const winner = hS >= aS ? match.homeTeamId : match.awayTeamId;
      const teamList = await getTeamsByTournament(match.tournamentId);
      const championTeam = teamList.find((t2) => t2.id === winner);
      await updateTournamentStatus(match.tournamentId, "finished", championTeam?.name);
    }
    return { ok: true };
  }),
  updateDetails: protectedProcedure.input(
    z2.object({
      matchId: z2.number(),
      matchDate: z2.string().optional(),
      matchTime: z2.string().optional(),
      location: z2.string().optional()
    })
  ).mutation(async ({ input }) => {
    const match = await getMatchById(input.matchId);
    if (!match) throw new TRPCError3({ code: "NOT_FOUND", message: "Partida n\xE3o encontrada" });
    await updateMatchDetails(input.matchId, input.matchDate, input.matchTime, input.location);
    return { ok: true };
  }),
  resetScore: protectedProcedure.input(z2.object({ matchId: z2.number() })).mutation(async ({ input }) => {
    const match = await getMatchById(input.matchId);
    if (!match) throw new TRPCError3({ code: "NOT_FOUND", message: "Partida n\xE3o encontrada" });
    await resetMatchScore(input.matchId);
    if (match.phase === "final") {
      await updateTournamentStatus(match.tournamentId, "final");
    }
    return { ok: true };
  })
});
var seedRouter = router({
  seedExample: protectedProcedure.mutation(async () => {
    const tournamentId = await createTournament(1, "Sub-9 MASC", "Sub-9 Masculino", { groupCount: 1 });
    for (const team of DEFAULT_TEAMS) {
      await createTeam(tournamentId, team.name, team.shortName, team.color, "A");
    }
    return { id: tournamentId };
  }),
  checkAndSeed: publicProcedure.mutation(async () => {
    const all = await getAllTournaments();
    if (all.length === 0) {
      const tournamentId = await createTournament(1, "Sub-9 MASC", "Sub-9 Masculino", { groupCount: 1 });
      for (const team of DEFAULT_TEAMS) {
        await createTeam(tournamentId, team.name, team.shortName, team.color, "A");
      }
      return { seeded: true, tournamentId };
    }
    return { seeded: false };
  })
});
var appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true };
    })
  }),
  portal: portalRouter,
  tournament: tournamentRouter,
  match: matchRouter,
  seed: seedRouter
});

// server/_core/context.ts
async function createContext(opts) {
  let user = null;
  try {
    user = await sdk.authenticateRequest(opts.req);
  } catch (error) {
    user = null;
  }
  return {
    req: opts.req,
    res: opts.res,
    user
  };
}

// server/_core/vite.ts
import express from "express";
import fs2 from "fs";
import { nanoid } from "nanoid";
import path2 from "path";
import { createServer as createViteServer } from "vite";

// vite.config.ts
import { jsxLocPlugin } from "@builder.io/vite-plugin-jsx-loc";
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import fs from "node:fs";
import path from "node:path";
import { defineConfig } from "vite";
import { vitePluginManusRuntime } from "vite-plugin-manus-runtime";
var PROJECT_ROOT = import.meta.dirname;
var LOG_DIR = path.join(PROJECT_ROOT, ".manus-logs");
var MAX_LOG_SIZE_BYTES = 1 * 1024 * 1024;
var TRIM_TARGET_BYTES = Math.floor(MAX_LOG_SIZE_BYTES * 0.6);
function ensureLogDir() {
  if (!fs.existsSync(LOG_DIR)) {
    fs.mkdirSync(LOG_DIR, { recursive: true });
  }
}
function trimLogFile(logPath, maxSize) {
  try {
    if (!fs.existsSync(logPath) || fs.statSync(logPath).size <= maxSize) {
      return;
    }
    const lines = fs.readFileSync(logPath, "utf-8").split("\n");
    const keptLines = [];
    let keptBytes = 0;
    const targetSize = TRIM_TARGET_BYTES;
    for (let i = lines.length - 1; i >= 0; i--) {
      const lineBytes = Buffer.byteLength(`${lines[i]}
`, "utf-8");
      if (keptBytes + lineBytes > targetSize) break;
      keptLines.unshift(lines[i]);
      keptBytes += lineBytes;
    }
    fs.writeFileSync(logPath, keptLines.join("\n"), "utf-8");
  } catch {
  }
}
function writeToLogFile(source, entries) {
  if (entries.length === 0) return;
  ensureLogDir();
  const logPath = path.join(LOG_DIR, `${source}.log`);
  const lines = entries.map((entry) => {
    const ts = (/* @__PURE__ */ new Date()).toISOString();
    return `[${ts}] ${JSON.stringify(entry)}`;
  });
  fs.appendFileSync(logPath, `${lines.join("\n")}
`, "utf-8");
  trimLogFile(logPath, MAX_LOG_SIZE_BYTES);
}
function vitePluginManusDebugCollector() {
  return {
    name: "manus-debug-collector",
    transformIndexHtml(html) {
      if (process.env.NODE_ENV === "production") {
        return html;
      }
      return {
        html,
        tags: [
          {
            tag: "script",
            attrs: {
              src: "/__manus__/debug-collector.js",
              defer: true
            },
            injectTo: "head"
          }
        ]
      };
    },
    configureServer(server) {
      server.middlewares.use("/__manus__/logs", (req, res, next) => {
        if (req.method !== "POST") {
          return next();
        }
        const handlePayload = (payload) => {
          if (payload.consoleLogs?.length > 0) {
            writeToLogFile("browserConsole", payload.consoleLogs);
          }
          if (payload.networkRequests?.length > 0) {
            writeToLogFile("networkRequests", payload.networkRequests);
          }
          if (payload.sessionEvents?.length > 0) {
            writeToLogFile("sessionReplay", payload.sessionEvents);
          }
          res.writeHead(200, { "Content-Type": "application/json" });
          res.end(JSON.stringify({ success: true }));
        };
        const reqBody = req.body;
        if (reqBody && typeof reqBody === "object") {
          try {
            handlePayload(reqBody);
          } catch (e) {
            res.writeHead(400, { "Content-Type": "application/json" });
            res.end(JSON.stringify({ success: false, error: String(e) }));
          }
          return;
        }
        let body = "";
        req.on("data", (chunk) => {
          body += chunk.toString();
        });
        req.on("end", () => {
          try {
            const payload = JSON.parse(body);
            handlePayload(payload);
          } catch (e) {
            res.writeHead(400, { "Content-Type": "application/json" });
            res.end(JSON.stringify({ success: false, error: String(e) }));
          }
        });
      });
    }
  };
}
var plugins = [react(), tailwindcss(), jsxLocPlugin(), vitePluginManusRuntime(), vitePluginManusDebugCollector()];
var vite_config_default = defineConfig({
  plugins,
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "client", "src"),
      "@shared": path.resolve(import.meta.dirname, "shared")
    }
  },
  envDir: path.resolve(import.meta.dirname),
  root: path.resolve(import.meta.dirname, "client"),
  publicDir: path.resolve(import.meta.dirname, "client", "public"),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true
  },
  server: {
    host: true,
    allowedHosts: [
      ".manuspre.computer",
      ".manus.computer",
      ".manus-asia.computer",
      ".manuscomputer.ai",
      ".manusvm.computer",
      "localhost",
      "127.0.0.1"
    ],
    fs: {
      strict: true,
      deny: ["**/.*"]
    }
  }
});

// server/_core/vite.ts
async function setupVite(app, server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true
  };
  const vite = await createViteServer({
    ...vite_config_default,
    configFile: false,
    server: serverOptions,
    appType: "custom"
  });
  app.use(vite.middlewares);
  app.use("*", async (req, res, next) => {
    const url = req.originalUrl;
    try {
      const clientTemplate = path2.resolve(
        import.meta.dirname,
        "../..",
        "client",
        "index.html"
      );
      let template = await fs2.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid()}"`
      );
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e);
      next(e);
    }
  });
}
function serveStatic(app) {
  const distPath = process.env.NODE_ENV === "development" ? path2.resolve(import.meta.dirname, "../..", "dist", "public") : path2.resolve(import.meta.dirname, "public");
  if (!fs2.existsSync(distPath)) {
    console.error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }
  app.use(express.static(distPath));
  app.use("*", (_req, res) => {
    res.sendFile(path2.resolve(distPath, "index.html"));
  });
}

// server/_core/index.ts
init_env();
init_db();
function isPortAvailable(port) {
  return new Promise((resolve) => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}
async function findAvailablePort(startPort = 3e3) {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}
async function startServer() {
  const app = express2();
  const server = createServer(app);
  app.use(express2.json({ limit: "50mb" }));
  app.use(express2.urlencoded({ limit: "50mb", extended: true }));
  registerOAuthRoutes(app);
  app.get("/health", (req, res) => res.json({ status: "ok", timestamp: (/* @__PURE__ */ new Date()).toISOString() }));
  app.post("/api/admin/login", async (req, res) => {
    const { email, password, portalId } = req.body;
    if (password === process.env.ADMIN_PASSWORD && (!email || email === "admin")) {
      const token = await sdk.createSessionToken(ENV.ownerOpenId, { name: "Super Admin" });
      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, token, cookieOptions);
      return res.json({ success: true, role: "admin" });
    }
    if (email) {
      const user = await getUserByEmail(email);
      if (user && user.role === "admin" && user.password === password) {
        const token = await sdk.createSessionToken(user.openId, { name: user.name || "Admin" });
        const cookieOptions = getSessionCookieOptions(req);
        res.cookie(COOKIE_NAME, token, cookieOptions);
        return res.json({ success: true, role: "admin", portalId: user.portalId });
      }
    }
    if (portalId) {
      const portal = (await Promise.resolve().then(() => (init_db(), db_exports))).getPortalBySlug;
      const db = await Promise.resolve().then(() => (init_db(), db_exports));
      const portals2 = await db.getAllPortals();
      const targetPortal = portals2.find((p) => p.id === portalId);
      if (targetPortal && targetPortal.adminPassword && password === targetPortal.adminPassword) {
        const portalAdminOpenId = `portal_admin_${targetPortal.id}`;
        await db.upsertUser({
          openId: portalAdminOpenId,
          name: `${targetPortal.name} Admin`,
          role: "admin"
          // We can't easily store portalId in user table without schema change, 
          // but we can imply it from the openId or a naming convention
        });
        const token = await sdk.createSessionToken(portalAdminOpenId, { name: `${targetPortal.name} Admin` });
        const cookieOptions = getSessionCookieOptions(req);
        res.cookie(COOKIE_NAME, token, cookieOptions);
        return res.json({ success: true, role: "admin", portalId: targetPortal.id });
      }
    }
    res.status(401).json({ error: "Senha incorreta ou portal n\xE3o encontrado" });
  });
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext
    })
  );
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }
  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);
  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }
  server.listen(port, "0.0.0.0", async () => {
    console.log(`Server running on http://0.0.0.0:${port}/ (detected from PORT env: ${process.env.PORT || "not set"})`);
    console.log(`Local Access: http://localhost:${port}/`);
    try {
      const email = "apefia1998@gmail.com";
      const password = "@coi2046WII#";
      const database = await getDb();
      if (database) {
        const { users: usersTable } = await Promise.resolve().then(() => (init_schema(), schema_exports));
        await database.insert(usersTable).values({
          openId: `manual_master_seed`,
          name: "Super Admin (ApefA)",
          email,
          password,
          role: "admin",
          lastSignedIn: /* @__PURE__ */ new Date()
        }).onDuplicateKeyUpdate({
          set: { password, role: "admin" }
        });
        console.log(`[System] Super Admin seed successful for ${email}`);
      }
    } catch (e) {
      console.error("[System] Failed to seed super admin:", e);
    }
    try {
      const database = await getDb();
      if (database) {
        console.log("[System] Connecting to database for health check...");
        const portals2 = await getAllPortals();
        console.log(`[System] Database OK. Found ${portals2.length} portals in schema.`);
      } else {
        console.error("[System] Database connection failed: _db is null");
      }
    } catch (e) {
      console.error("[System] Database initialization check failed:", e);
    }
  });
}
startServer().catch(console.error);
